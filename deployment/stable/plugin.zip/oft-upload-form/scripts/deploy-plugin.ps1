$ErrorActionPreference = 'Stop'

$source = Split-Path -Parent $PSScriptRoot
$deploymentRoot = Join-Path $source 'deployment'
$stageRoot = Join-Path $deploymentRoot 'stage'
$configPath = Join-Path $source 'deployment.config.json'
$mainPluginFile = Join-Path $source 'oft-upload-form.php'
$readmePath = Join-Path $source 'readme.txt'
$pluginSlug = 'oft-upload-form'
$versionPattern = '[0-9A-Za-z][0-9A-Za-z\.\-\+]*'

function Set-FileContentIfChanged {
	param([string]$Path,[string]$Content)
	$current = Get-Content -LiteralPath $Path -Raw
	if ($current -cne $Content) {
		$encoding = New-Object System.Text.UTF8Encoding($false)
		[System.IO.File]::WriteAllText($Path, $Content, $encoding)
	}
}

function ConvertTo-HtmlList {
	param([string[]]$Items)
	$listItems = foreach ($item in $Items) { '<li>' + [System.Security.SecurityElement]::Escape($item) + '</li>' }
	return '<ul>' + ($listItems -join '') + '</ul>'
}

function Get-ReadmeChangelogEntry {
	param([string]$Version,[string[]]$Items)
	$lines = @("= $Version =", '')
	foreach ($item in $Items) { $lines += "* $item" }
	return ($lines -join [Environment]::NewLine)
}

function Get-HtmlChangelogEntry {
	param([string]$Version,[string[]]$Items)
	return '<h4>' + [System.Security.SecurityElement]::Escape($Version) + '</h4>' + (ConvertTo-HtmlList -Items $Items)
}

function Normalize-History {
	param([array]$History,[string]$CurrentVersion,[string[]]$CurrentNotes,[string]$ConfigPath)
	$normalized = @()
	foreach ($entry in @($History)) {
		if (-not $entry.PSObject.Properties.Name.Contains('version')) {
			throw "Each release_history entry in $ConfigPath must include a version."
		}
		$entryVersion = [string]$entry.version
		$entryNotes = @($entry.notes | Where-Object { $_ -and $_.Trim() })
		if ([string]::IsNullOrWhiteSpace($entryVersion) -or $entryNotes.Count -eq 0) {
			throw "Each release_history entry in $ConfigPath must include a version and at least one note."
		}
		$normalized += [pscustomobject]@{ version = $entryVersion; notes = $entryNotes }
	}
	$currentEntry = $normalized | Where-Object { $_.version -eq $CurrentVersion } | Select-Object -First 1
	if (-not $currentEntry) {
		$normalized = ,([pscustomobject]@{ version = $CurrentVersion; notes = $CurrentNotes }) + $normalized
		$currentEntry = $normalized[0]
	}
	$currentEntry.notes = $CurrentNotes
	return $normalized
}

function Get-UpdatedPluginFileContent {
	param([string]$Content,[string]$Version,[string]$VersionPattern)
	$updated = [regex]::Replace($Content, "(?m)^(\s*\*\s*Version:\s*)$VersionPattern", '${1}' + $Version, 1)
	$updated = [regex]::Replace($updated, "define\(\s*'OFTUF_VERSION'\s*,\s*'$VersionPattern'\s*\);", "define( 'OFTUF_VERSION', '$Version' );", 1)
	return $updated
}

function Get-UpdatedReadmeContent {
	param([string]$Content,[string]$StableVersion,[array]$History)
	$updated = [regex]::Replace($Content, "(?m)^(Stable tag:\s*)$versionPattern$", '${1}' + $StableVersion, 1)
	$entries = foreach ($entry in $History) { Get-ReadmeChangelogEntry -Version $entry.version -Items $entry.notes }
	$block = ($entries -join ([Environment]::NewLine + [Environment]::NewLine)) + [Environment]::NewLine
	return [regex]::Replace($updated, '(?ms)(== Changelog ==\r?\n\r?\n).*$','${1}' + $block,1)
}

function Build-TrackArtifacts {
	param(
		[string]$Track,
		[pscustomobject]$TrackConfig,
		[pscustomobject]$Config,
		[string]$SourceRoot,
		[string]$DeploymentRoot,
		[string]$StageRoot,
		[string]$MainPluginFile,
		[string]$ReadmePath,
		[string]$VersionPattern
	)

	$trackRoot = Join-Path $DeploymentRoot $Track
	$trackStageRoot = Join-Path $StageRoot $Track
	$stagePluginRoot = Join-Path $trackStageRoot $Config.slug
	New-Item -ItemType Directory -Path $stagePluginRoot -Force | Out-Null

	$robocopyArgs = @(
		$SourceRoot
		$stagePluginRoot
		'/MIR'
		'/XD', '.git', '.vscode', 'deployment'
		'/XF', '.gitignore', 'deployment.config.json'
		'/R:2'
		'/W:1'
		'/NFL'
		'/NDL'
		'/NJH'
		'/NJS'
	)
	& robocopy @robocopyArgs
	if ($LASTEXITCODE -ge 8) {
		throw "Deployment packaging failed for $Track with robocopy exit code $LASTEXITCODE."
	}

	$stagePluginFile = Join-Path $stagePluginRoot 'oft-upload-form.php'
	$stageReadmePath = Join-Path $stagePluginRoot 'readme.txt'
	$trackVersion = [string]$TrackConfig.version
	$trackNotes = @($TrackConfig.release_notes | Where-Object { $_ -and $_.Trim() })
	$trackHistory = Normalize-History -History $TrackConfig.release_history -CurrentVersion $trackVersion -CurrentNotes $trackNotes -ConfigPath $configPath

	$pluginContent = Get-Content $stagePluginFile -Raw
	$pluginContent = Get-UpdatedPluginFileContent -Content $pluginContent -Version $trackVersion -VersionPattern $VersionPattern
	Set-FileContentIfChanged -Path $stagePluginFile -Content $pluginContent

	$readmeContent = Get-Content $stageReadmePath -Raw
	$readmeContent = Get-UpdatedReadmeContent -Content $readmeContent -StableVersion $trackVersion -History $trackHistory
	Set-FileContentIfChanged -Path $stageReadmePath -Content $readmeContent

	$trackUrlBase = 'https://onefeaturetrap.com/plugin-downloads/' + $Config.slug + '/' + $Track
	$jsonSections = [ordered]@{
		description  = $Config.sections.description
		installation = $Config.sections.installation
		changelog    = (($trackHistory | ForEach-Object { Get-HtmlChangelogEntry -Version $_.version -Items $_.notes }) -join '')
	}
	$jsonConfig = [ordered]@{
		name          = $Config.name
		slug          = $Config.slug
		version       = $trackVersion
		channel       = $Track
		requires      = $Config.requires
		tested        = $Config.tested
		requires_php  = $Config.requires_php
		last_updated  = $TrackConfig.last_updated
		homepage      = $Config.homepage
		download_url  = $trackUrlBase + '/plugin.zip'
		sections      = $jsonSections
		banners       = $Config.banners
		icons         = $Config.icons
	}

	New-Item -ItemType Directory -Path $trackRoot -Force | Out-Null
	$zipPath = Join-Path $trackRoot 'plugin.zip'
	$jsonPath = Join-Path $trackRoot 'metadata.json'

	& tar -a -c -f $zipPath -C $trackStageRoot $Config.slug
	if ($LASTEXITCODE -ne 0) {
		throw "ZIP packaging failed for $Track with tar exit code $LASTEXITCODE."
	}

	$json = ($jsonConfig | ConvertTo-Json -Depth 10).Replace('\u003c', '<').Replace('\u003e', '>').Replace('\u0026', '&')
	[System.IO.File]::WriteAllBytes($jsonPath, [System.Text.Encoding]::UTF8.GetBytes($json + [Environment]::NewLine))
}

if (-not (Test-Path -LiteralPath $configPath)) {
	throw "Missing deployment config: $configPath"
}

$config = Get-Content $configPath -Raw | ConvertFrom-Json
$pluginFileContent = Get-Content $mainPluginFile -Raw
$readmeContent = Get-Content $readmePath -Raw

if (-not $config.PSObject.Properties.Name.Contains('tracks')) {
	throw "Missing tracks in $configPath"
}

$sourceNotes = @($config.source_release_notes | Where-Object { $_ -and $_.Trim() })
if ($sourceNotes.Count -eq 0) {
	throw "source_release_notes in $configPath must contain at least one item."
}

$sourceHistory = Normalize-History -History $config.source_release_history -CurrentVersion ([string]$config.source_version) -CurrentNotes $sourceNotes -ConfigPath $configPath

if ($pluginFileContent -notmatch "Version:\s*$versionPattern") {
	throw "Could not read plugin version from $mainPluginFile"
}

if ($pluginFileContent -notmatch "define\(\s*'OFTUF_VERSION'\s*,\s*'$versionPattern'\s*\);") {
	throw "Could not read OFTUF_VERSION from $mainPluginFile"
}

$updatedPluginFileContent = Get-UpdatedPluginFileContent -Content $pluginFileContent -Version ([string]$config.source_version) -VersionPattern $versionPattern
Set-FileContentIfChanged -Path $mainPluginFile -Content $updatedPluginFileContent

$stableTrackVersion = [string]$config.tracks.stable.version
$updatedReadmeContent = Get-UpdatedReadmeContent -Content $readmeContent -StableVersion $stableTrackVersion -History $sourceHistory
Set-FileContentIfChanged -Path $readmePath -Content $updatedReadmeContent

if (Test-Path -LiteralPath $deploymentRoot) {
	Remove-Item -LiteralPath $deploymentRoot -Recurse -Force
}

New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null

foreach ($track in @('stable', 'beta')) {
	if (-not $config.tracks.PSObject.Properties.Name.Contains($track)) {
		throw "Missing tracks.$track in $configPath"
	}
	Build-TrackArtifacts -Track $track -TrackConfig $config.tracks.$track -Config $config -SourceRoot $source -DeploymentRoot $deploymentRoot -StageRoot $stageRoot -MainPluginFile $mainPluginFile -ReadmePath $readmePath -VersionPattern $versionPattern
}

Remove-Item -LiteralPath $stageRoot -Recurse -Force

Write-Host "Deployment packages created:"
Write-Host "Stable: $(Join-Path $deploymentRoot 'stable')"
Write-Host "Beta:   $(Join-Path $deploymentRoot 'beta')"
Write-Host "Source version synced to: $($config.source_version)"
